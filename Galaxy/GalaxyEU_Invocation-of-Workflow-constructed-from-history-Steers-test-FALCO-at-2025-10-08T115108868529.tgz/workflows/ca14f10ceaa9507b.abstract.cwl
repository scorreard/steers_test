class: Workflow
cwlVersion: v1.2
inputs:
  test_hifi.fastq.gz:
    type: File
label: Workflow constructed from history 'Steers test FALCO'
outputs: {}
steps:
  _unlabeled_step_1:
    in:
      library|input_1:
        source: test_hifi.fastq.gz
    out:
    - out1
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
  _unlabeled_step_2:
    in:
      input_file:
        source: test_hifi.fastq.gz
    out: []
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
  _unlabeled_step_3:
    in:
      mode|reads:
        source: _unlabeled_step_1/out1
    out: []
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
