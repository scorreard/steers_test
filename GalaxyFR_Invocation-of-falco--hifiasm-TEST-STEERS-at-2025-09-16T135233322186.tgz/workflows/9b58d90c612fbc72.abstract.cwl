class: Workflow
label: falco + hifiasm TEST STEERS
cwlVersion: v1.2
inputs:
  HiFi raw reads collection:
    format:
    - fastq.gz
    fields: null
    column_definitions: null
    id: HiFi raw reads collection
    type: File[]
outputs:
  raw_unitigs:
    outputSource: 3/raw_unitigs
    type: File
steps:
  '1':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      input_file:
        source: HiFi raw reads collection
    out: []
  '2':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      library|input_1:
        source: HiFi raw reads collection
    out:
    - out1
    - report
  '3':
    run:
      class: Operation
      doc: ''
      inputs: {}
      outputs: {}
    in:
      mode|reads:
        source: 2/out1
    out:
    - raw_unitigs
